from flask import Flask, jsonify, render_template, request

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/ty", methods = ['GET','POST'])
def ty():
    f_name = request.form['f_name']
    l_name = request.form['l_name']
    email = request.form['e_mail']
    subject = request.form['sub']
    print("\n\n"*10)
    message = request.form['message']
    form_data = {'f_name':f_name,
                 'l_name':l_name,
                 'email':email,
                 'subject':subject,
                 'message':message}
    print(form_data)
    return render_template("ty.html",name = f_name)



if __name__ == '__main__':
    app.run('0.0.0.0',port=5001, debug = True)




#
